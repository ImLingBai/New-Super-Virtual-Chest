package afkx.nsvc;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class I18n {
    private static final Map<String, String> EN = new HashMap<>();
    private static final Map<String, String> ZH = new HashMap<>();

    static {
        // ========== 英文 ==========
        EN.put("nsvc.size.small", "Small");
        EN.put("nsvc.size.large", "Large");
        EN.put("nsvc.error.create.other_player", "You cannot create private chests for other players!");
        EN.put("nsvc.error.chest_exists", "Virtual chest '%s' already exists!");
        EN.put("nsvc.error.create_failed", "Creation failed!");
        EN.put("nsvc.create.success", "Virtual chest '%s' (%s slots) created successfully!");
        EN.put("nsvc.error.not_exist", "Virtual chest '%s' does not exist!");
        EN.put("nsvc.error.pending_deletion", "This chest is pending deletion and cannot be opened!");
        EN.put("nsvc.error.no_permission_private", "You don't have permission to access this private chest!");
        EN.put("nsvc.chest.title", "Virtual Chest: %s");
        EN.put("nsvc.open.opening", "Opening virtual chest '%s'");
        EN.put("nsvc.error.type_mismatch", "Chest type mismatch!");
        EN.put("nsvc.error.not_pending", "This chest is not pending deletion!");
        EN.put("nsvc.error.no_permission_cancel", "You don't have permission to cancel this deletion!");
        EN.put("nsvc.delete.cancelled", "Deletion of chest '%s' cancelled.");
        EN.put("nsvc.delete.admin_success", "Admin successfully deleted chest '%s'.");
        EN.put("nsvc.delete.public_pending", "Chest '%s' is now scheduled for deletion (3 in-game days). Use '/NSvc allplayer delete %s close' to cancel.");
        EN.put("nsvc.delete.public_done", "Chest '%s' has been deleted after waiting period.");
        EN.put("nsvc.delete.remaining_days", "Chest still pending deletion, approximately %s game days remaining.");
        EN.put("nsvc.delete.private_confirm", "Please re-enter the command to confirm deletion of your private chest '%s'.");
        EN.put("nsvc.delete.confirm_timeout", "Confirmation timed out. Please initiate deletion again.");
        EN.put("nsvc.delete.private_done", "Private chest '%s' has been successfully deleted.");
        EN.put("nsvc.list.header", "=== Virtual Chest List (%s) ===");
        EN.put("nsvc.list.pending", " [Pending]");
        EN.put("nsvc.list.entry", " - %s (%s slots)%s");
        EN.put("nsvc.list.empty", "No chests found.");

        // ========== 简体中文 ==========
        ZH.put("nsvc.size.small", "小");
        ZH.put("nsvc.size.large", "大");
        ZH.put("nsvc.error.create.other_player", "你不能为其他玩家创建私有箱子！");
        ZH.put("nsvc.error.chest_exists", "名为 '%s' 的虚拟箱子已存在！");
        ZH.put("nsvc.error.create_failed", "创建失败！");
        ZH.put("nsvc.create.success", "虚拟箱子 '%s' (%s 格) 创建成功！");
        ZH.put("nsvc.error.not_exist", "虚拟箱子 '%s' 不存在！");
        ZH.put("nsvc.error.pending_deletion", "该箱子正在等待删除，无法打开！");
        ZH.put("nsvc.error.no_permission_private", "你没有权限打开这个私有箱子！");
        ZH.put("nsvc.chest.title", "虚拟箱子: %s");
        ZH.put("nsvc.open.opening", "正在打开虚拟箱子 '%s'");
        ZH.put("nsvc.error.type_mismatch", "箱子类型与命令目标不符！");
        ZH.put("nsvc.error.not_pending", "该箱子未处于待删除状态！");
        ZH.put("nsvc.error.no_permission_cancel", "你没有权限取消这个箱子的删除！");
        ZH.put("nsvc.delete.cancelled", "已取消删除箱子 '%s'。");
        ZH.put("nsvc.delete.admin_success", "管理员已成功删除箱子 '%s'。");
        ZH.put("nsvc.delete.public_pending", "箱子 '%s' 正在删除中，预计游戏内3天。使用 '/NSvc allplayer delete %s close' 取消。");
        ZH.put("nsvc.delete.public_done", "箱子 '%s' 等待时间已到，已成功删除。");
        ZH.put("nsvc.delete.remaining_days", "箱子还在待删除状态，还需约 %s 游戏天。");
        ZH.put("nsvc.delete.private_confirm", "请再次输入相同命令以确认删除私有箱子 '%s'。");
        ZH.put("nsvc.delete.confirm_timeout", "确认超时，请重新发起删除命令。");
        ZH.put("nsvc.delete.private_done", "私有箱子 '%s' 已成功删除。");
        ZH.put("nsvc.list.header", "=== 虚拟箱子列表 (%s) ===");
        ZH.put("nsvc.list.pending", " [待删除]");
        ZH.put("nsvc.list.entry", " - %s (%s 格)%s");
        ZH.put("nsvc.list.empty", "没有找到符合条件的箱子。");
    }

    /**
     * 根据玩家客户端语言获取翻译文本
     * @param player 目标玩家 (可为 null，此时默认英文)
     * @param key    翻译键
     * @param args   格式化参数
     * @return 带格式的 Text 对象
     */
    public static class_2561 translate(class_3222 player, String key, Object... args) {
        String lang = "en_us";
        if (player != null) {
            // 通过玩家客户端的语言设置来判断 (例如 "zh_cn", "en_us")
            lang = player.method_53823().comp_1951();
        }
        Map<String, String> map = lang.startsWith("zh") ? ZH : EN;
        String pattern = map.getOrDefault(key, key);
        return class_2561.method_43470(String.format(pattern, args));
    }

    // 无玩家上下文时使用 (控制台等)
    public static class_2561 translate(String key, Object... args) {
        return translate(null, key, args);
    }
}