package afkx.nsvc;

import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_5218;
import net.minecraft.class_7225;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class VirtualChestData {
    private static final String FILE_NAME = "nsvc_virtualchests.dat";
    private static VirtualChestData INSTANCE;

    private final Map<String, VirtualChest> chests = new HashMap<>();

    private VirtualChestData() {}

    public static VirtualChestData getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new VirtualChestData();
        }
        return INSTANCE;
    }

    public static void load(MinecraftServer server) {
        INSTANCE = new VirtualChestData();
        Path filePath = getFilePath(server);
        VirtualChestMod.LOGGER.info("尝试从路径加载数据: {}", filePath.toAbsolutePath());
        if (Files.exists(filePath)) {
            try {
                class_2487 nbt = class_2507.method_30613(filePath, net.minecraft.class_2505.method_53898());
                class_2499 chestList = nbt.method_10554("chests").orElse(new class_2499());
                class_7225.class_7874 registries = server.method_3847(class_1937.field_25179).method_30349();
                for (int i = 0; i < chestList.size(); i++) {
                    chestList.method_10602(i).ifPresent(chestTag -> {
                        VirtualChest chest = VirtualChest.fromNbt(chestTag, registries);
                        INSTANCE.chests.put(chest.getName(), chest);
                    });
                }
                VirtualChestMod.LOGGER.info("成功加载虚拟箱子数据，共 {} 个箱子。", INSTANCE.chests.size());
            } catch (IOException e) {
                VirtualChestMod.LOGGER.error("加载虚拟箱子数据失败！", e);
            }
        } else {
            VirtualChestMod.LOGGER.info("未找到数据文件，将创建新数据。");
        }
    }

    public static void save(MinecraftServer server) {
        if (INSTANCE == null) {
            VirtualChestMod.LOGGER.warn("尝试保存时 INSTANCE 为空，跳过保存。");
            return;
        }
        Path filePath = getFilePath(server);
        VirtualChestMod.LOGGER.info("正在保存虚拟箱子数据到: {}", filePath.toAbsolutePath());
        try {
            class_2487 nbt = new class_2487();
            class_2499 chestList = new class_2499();
            class_7225.class_7874 registries = server.method_3847(class_1937.field_25179).method_30349();
            for (VirtualChest chest : INSTANCE.chests.values()) {
                chestList.add(chest.writeNbt(new class_2487(), registries));
            }
            nbt.method_10566("chests", chestList);
            Files.createDirectories(filePath.getParent());
            class_2507.method_30614(nbt, filePath);
            VirtualChestMod.LOGGER.info("成功保存虚拟箱子数据，共 {} 个箱子。", INSTANCE.chests.size());
        } catch (IOException e) {
            VirtualChestMod.LOGGER.error("保存虚拟箱子数据失败！", e);
        }
    }

    public boolean createChest(String name, VirtualChest.Size size, UUID owner, boolean isPublic) {
        if (chests.containsKey(name)) return false;
        VirtualChest chest = isPublic ? new VirtualChest(name, size) : new VirtualChest(name, size, owner);
        chests.put(name, chest);
        VirtualChestMod.LOGGER.info("已创建箱子 '{}'，所有者: {}，公共: {}", name, owner != null ? owner : "公共", isPublic);
        return true;
    }

    public VirtualChest getChest(String name) {
        return chests.get(name);
    }

    public int getChestCount() {
        return chests.size();
    }

    public Set<String> getChestNames() {
        return chests.keySet();
    }

    public boolean deleteChest(String name) {
        boolean removed = chests.remove(name) != null;
        if (removed) {
            VirtualChestMod.LOGGER.info("已删除箱子 '{}'", name);
        }
        return removed;
    }

    public Collection<VirtualChest> getAllChests() {
        return chests.values();
    }

    private static Path getFilePath(MinecraftServer server) {
        return server.method_27050(class_5218.field_24188).resolve(FILE_NAME).normalize().toAbsolutePath();
    }
}