package afkx.nsvc;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1937;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VirtualChestMod implements ModInitializer {
    public static final String MOD_ID = "nsvc";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("NS Virtual Chest (Server-side only) initializing...");

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            VirtualChestData.load(server);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            VirtualChestData.save(server);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            VirtualChestCommand.register(dispatcher);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            VirtualChestData data = VirtualChestData.getInstance();
            long currentTime = server.method_3847(class_1937.field_25179).method_75260();
            for (VirtualChest chest : data.getAllChests()) {
                // Auto-delete public chests after 3 in-game days
                if (chest.isPendingDeletion() && chest.isPublic()) {
                    if (currentTime - chest.getDeletionStartTime() >= 72000L) {
                        data.deleteChest(chest.getName());
                        LOGGER.info("Public chest '{}' waiting time expired, auto-deleted.", chest.getName());
                    }
                }
                // Auto-cancel private chest deletion confirmation after 1 minute
                if (chest.isPendingDeletion() && !chest.isPublic()) {
                    if (chest.getDeletionStartTime() > 0 && currentTime - chest.getDeletionStartTime() > 1200) {
                        chest.setPendingDeletion(false, 0);
                    }
                }
            }
        });

        LOGGER.info("NS Virtual Chest initialized! Admin tag: 'nsvc_admin'");
    }
}