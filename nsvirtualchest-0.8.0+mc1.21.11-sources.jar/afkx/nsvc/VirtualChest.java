package afkx.nsvc;

import com.mojang.serialization.DataResult;
import java.util.UUID;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_7225;

public class VirtualChest extends class_1277 {
    private final String name;
    private final Size chestSize;
    private final UUID owner;
    private final boolean isPublic;
    private boolean pendingDeletion;
    private long deletionStartTime;

    public enum Size {
        SMALL(27),
        LARGE(54);

        private final int slots;
        Size(int slots) { this.slots = slots; }
        public int getSlots() { return slots; }
        public String getDisplayName() { return this == SMALL ? "small" : "large"; }
    }

    public VirtualChest(String name, Size size) {
        this(name, size, null, true);
    }

    public VirtualChest(String name, Size size, UUID owner) {
        this(name, size, owner, false);
    }

    private VirtualChest(String name, Size size, UUID owner, boolean isPublic) {
        super(size.getSlots());
        this.name = name;
        this.chestSize = size;
        this.owner = owner;
        this.isPublic = isPublic;
        this.pendingDeletion = false;
        this.deletionStartTime = 0;
    }

    public String getName() { return name; }
    public Size getChestSize() { return chestSize; }
    public UUID getOwner() { return owner; }
    public boolean isPublic() { return isPublic; }
    public boolean isPendingDeletion() { return pendingDeletion; }
    public long getDeletionStartTime() { return deletionStartTime; }

    public void setPendingDeletion(boolean pending, long startTime) {
        this.pendingDeletion = pending;
        this.deletionStartTime = startTime;
    }

    public class_2487 writeNbt(class_2487 nbt, class_7225.class_7874 registries) {
        nbt.method_10582("name", name);
        nbt.method_10582("size", chestSize.name());
        nbt.method_10556("public", isPublic);
        if (owner != null) {
            nbt.method_10582("owner", owner.toString()); // 将 UUID 保存为字符串
        }
        nbt.method_10556("pendingDeletion", pendingDeletion);
        if (pendingDeletion) {
            nbt.method_10544("deletionStartTime", deletionStartTime);
        }

        class_2499 items = new class_2499();
        for (int i = 0; i < chestSize.getSlots(); i++) {
            class_1799 stack = method_5438(i);
            if (!stack.method_7960()) {
                final int slot = i;
                DataResult<class_2520> result = class_1799.field_49266.encodeStart(registries.method_57093(class_2509.field_11560), stack);
                result.resultOrPartial(error -> {
                    VirtualChestMod.LOGGER.error("编码物品失败，槽位 {}: {}", slot, error);
                }).ifPresent(element -> {
                    class_2487 itemEntry = new class_2487();
                    itemEntry.method_10569("Slot", slot);
                    itemEntry.method_10566("Item", element);
                    items.add(itemEntry);
                });
            }
        }
        nbt.method_10566("Items", items);
        return nbt;
    }

    public static VirtualChest fromNbt(class_2487 nbt, class_7225.class_7874 registries) {
        String name = nbt.method_10558("name").orElse("unknown");
        String sizeStr = nbt.method_10558("size").orElse("LARGE");
        boolean isPublic = nbt.method_10577("public").orElse(false);
        
        // 从字符串读取 UUID
        UUID owner = null;
        String ownerStr = nbt.method_10558("owner").orElse(null);
        if (ownerStr != null && !ownerStr.isEmpty()) {
            try {
                owner = UUID.fromString(ownerStr);
            } catch (IllegalArgumentException e) {
                VirtualChestMod.LOGGER.error("无效的 UUID 字符串: {}", ownerStr);
            }
        }

        Size size;
        try {
            size = Size.valueOf(sizeStr);
        } catch (IllegalArgumentException e) {
            size = Size.LARGE;
        }
        VirtualChest chest = new VirtualChest(name, size, owner, isPublic);
        chest.pendingDeletion = nbt.method_10577("pendingDeletion").orElse(false);
        if (chest.pendingDeletion) {
            chest.deletionStartTime = nbt.method_10537("deletionStartTime").orElse(0L);
        }

        class_2499 items = nbt.method_10554("Items").orElse(new class_2499());
        for (int i = 0; i < items.size(); i++) {
            class_2487 itemEntry = items.method_10602(i).orElse(null);
            if (itemEntry != null) {
                int slot = itemEntry.method_10550("Slot").orElse(-1);
                if (slot >= 0 && slot < chest.chestSize.getSlots()) {
                    class_2520 itemElement = itemEntry.method_10580("Item");
                    if (itemElement != null) {
                        DataResult<class_1799> result = class_1799.field_49266.parse(registries.method_57093(class_2509.field_11560), itemElement);
                        var optionalStack = result.resultOrPartial(error -> {
                            VirtualChestMod.LOGGER.error("解码物品失败，槽位 {}: {}", slot, error);
                        });
                        if (optionalStack.isPresent()) {
                            chest.method_5447(slot, optionalStack.get());
                        }
                    }
                }
            }
        }
        return chest;
    }
}