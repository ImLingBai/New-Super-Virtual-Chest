package afkx.nsvc;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class AdminList {
    private static final String FILE_NAME = "nsvc_admins.json";
    private static AdminList INSTANCE;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Set<UUID> adminUUIDs = new HashSet<>();

    private AdminList() {}

    public static AdminList getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new AdminList();
        }
        return INSTANCE;
    }

    public boolean isAdmin(UUID uuid) {
        return adminUUIDs.contains(uuid);
    }

    public boolean addAdmin(UUID uuid) {
        boolean added = adminUUIDs.add(uuid);
        if (added) {
            save(); // 立即保存，但需要服务器实例，实际保存操作由外部调用 save(MinecraftServer)
        }
        return added;
    }

    public boolean removeAdmin(UUID uuid) {
        boolean removed = adminUUIDs.remove(uuid);
        if (removed) {
            save();
        }
        return removed;
    }

    public Set<UUID> getAdmins() {
        return new HashSet<>(adminUUIDs);
    }

    public boolean isEmpty() {
        return adminUUIDs.isEmpty();
    }

    public static void load(MinecraftServer server) {
        INSTANCE = new AdminList();
        Path filePath = getFilePath(server);
        if (Files.exists(filePath)) {
            try (Reader reader = Files.newBufferedReader(filePath, StandardCharsets.UTF_8)) {
                Set<UUID> loaded = GSON.fromJson(reader, new TypeToken<Set<UUID>>(){}.getType());
                if (loaded != null) {
                    INSTANCE.adminUUIDs.addAll(loaded);
                }
                VirtualChestMod.LOGGER.info("已加载 NSVC 管理员列表，共 {} 人", INSTANCE.adminUUIDs.size());
            } catch (IOException e) {
                VirtualChestMod.LOGGER.error("加载管理员列表失败！", e);
            }
        } else {
            VirtualChestMod.LOGGER.info("未找到管理员列表文件，将创建新文件。现在任何玩家都可以使用 /NSvc op <在线玩家> 成为第一个管理员！");
        }
    }

    public static void save() {
        // 空方法，实际保存需要服务器实例
    }

    public static void save(MinecraftServer server) {
        if (INSTANCE == null) return;
        Path filePath = getFilePath(server);
        try {
            Files.createDirectories(filePath.getParent());
            try (Writer writer = Files.newBufferedWriter(filePath, StandardCharsets.UTF_8)) {
                GSON.toJson(INSTANCE.adminUUIDs, writer);
            }
            VirtualChestMod.LOGGER.info("管理员列表已保存");
        } catch (IOException e) {
            VirtualChestMod.LOGGER.error("保存管理员列表失败！", e);
        }
    }

    private static Path getFilePath(MinecraftServer server) {
        return server.method_27050(class_5218.field_24188).resolve(FILE_NAME).normalize().toAbsolutePath();
    }
}