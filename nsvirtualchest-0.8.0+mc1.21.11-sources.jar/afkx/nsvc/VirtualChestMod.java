package afkx.nsvc;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1937;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VirtualChestMod implements ModInitializer {
    public static final String MOD_ID = "nsvc";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("NS Virtual Chest (Server-side only) initializing...");

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            VirtualChestData.load(server);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            VirtualChestData.save(server);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            VirtualChestCommand.register(dispatcher);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            VirtualChestData data = VirtualChestData.getInstance();
            // 修复：使用 server.getWorld(World.OVERWORLD).getTime() 获取时间
            long currentTime = server.method_3847(class_1937.field_25179).method_75260();
            for (VirtualChest chest : data.getAllChests()) {
                // 公共箱子自动删除检查
                if (chest.isPendingDeletion() && chest.isPublic()) {
                    if (currentTime - chest.getDeletionStartTime() >= 72000L) {
                        data.deleteChest(chest.getName());
                        LOGGER.info("公共箱子 '{}' 等待时间已到，自动删除。", chest.getName());
                    }
                }
                // 私有箱子确认超时检查（超过1分钟自动取消）
                if (chest.isPendingDeletion() && !chest.isPublic()) {
                    if (chest.getDeletionStartTime() > 0 && currentTime - chest.getDeletionStartTime() > 1200) {
                        chest.setPendingDeletion(false, 0);
                    }
                }
            }
        });

        LOGGER.info("NS Virtual Chest initialized! 管理员标签为 'nsvc_admin'");
    }
}