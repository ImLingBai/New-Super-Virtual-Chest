package afkx.nsvc;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class VirtualChestCommand {
    private static final long THREE_DAYS_TICKS = 72000L;
    private static final String ADMIN_TAG = "nsvc_admin";

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("NSvc")
                .then(method_9244("target", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            builder.suggest("allplayer");
                            ctx.getSource().method_9211().method_3760().method_14571()
                                    .forEach(p -> builder.suggest(p.method_5477().getString()));
                            return builder.buildFuture();
                        })
                        .then(method_9247("create")
                                .then(method_9244("name", StringArgumentType.word())
                                        .executes(ctx -> createChest(ctx, "large"))
                                        .then(method_9244("size", StringArgumentType.word())
                                                .suggests((ctx2, builder) -> {
                                                    builder.suggest("small");
                                                    builder.suggest("large");
                                                    return builder.buildFuture();
                                                })
                                                .executes(ctx -> {
                                                    String sizeArg = StringArgumentType.getString(ctx, "size").toLowerCase();
                                                    return createChest(ctx, sizeArg);
                                                })
                                        )
                                )
                        )
                        .then(method_9247("open")
                                .then(method_9244("name", StringArgumentType.word())
                                        .executes(VirtualChestCommand::openChest)
                                )
                        )
                        .then(method_9247("delete")
                                .then(method_9244("name", StringArgumentType.word())
                                        .executes(ctx -> deleteChest(ctx, false))
                                        .then(method_9247("close")
                                                .executes(ctx -> deleteChest(ctx, true))
                                        )
                                )
                        )
                        .then(method_9247("list")
                                .executes(VirtualChestCommand::listChests)
                        )
                )
        );
    }

    private static UUID resolveTarget(class_2168 source, String target, boolean mustBeOnline) throws CommandSyntaxException {
        if (target.equalsIgnoreCase("allplayer")) {
            return null;
        }
        class_3222 player = source.method_9211().method_3760().method_14566(target);
        if (player == null && mustBeOnline) {
            throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.dispatcherUnknownArgument().create();
        }
        return player != null ? player.method_5667() : null;
    }

    private static boolean hasAdminPermission(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player != null) {
            return player.method_5752().contains(ADMIN_TAG);
        }
        return true;
    }

    private static int createChest(CommandContext<class_2168> ctx, String sizeArg) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        String target = StringArgumentType.getString(ctx, "target");
        String name = StringArgumentType.getString(ctx, "name");
        VirtualChest.Size size = sizeArg.equals("small") ? VirtualChest.Size.SMALL : VirtualChest.Size.LARGE;
        boolean isPublic = target.equalsIgnoreCase("allplayer");
        UUID owner = isPublic ? null : resolveTarget(source, target, true);

        if (!hasAdminPermission(source)) {
            class_3222 self = source.method_9207();
            if (!isPublic && !self.method_5667().equals(owner)) {
                source.method_9213(class_2561.method_43471("nsvc.error.create.other_player"));
                return 0;
            }
        }

        VirtualChestData data = VirtualChestData.getInstance();
        if (data.getChest(name) != null) {
            source.method_9213(class_2561.method_43469("nsvc.error.chest_exists", name));
            return 0;
        }

        if (data.createChest(name, size, owner, isPublic)) {
            source.method_9226(() -> class_2561.method_43469("nsvc.create.success", name,
                    class_2561.method_43471(size == VirtualChest.Size.SMALL ? "nsvc.size.small" : "nsvc.size.large")
                            .method_27693(" " + size.getSlots())).method_27692(class_124.field_1060), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43471("nsvc.error.create_failed"));
            return 0;
        }
    }

    private static int openChest(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        class_3222 player = source.method_9207();
        String name = StringArgumentType.getString(ctx, "name");

        VirtualChestData data = VirtualChestData.getInstance();
        VirtualChest chest = data.getChest(name);
        if (chest == null) {
            source.method_9213(class_2561.method_43469("nsvc.error.not_exist", name));
            return 0;
        }

        if (chest.isPendingDeletion()) {
            source.method_9213(class_2561.method_43471("nsvc.error.pending_deletion"));
            return 0;
        }

        if (!hasAdminPermission(source)) {
            if (!chest.isPublic() && !player.method_5667().equals(chest.getOwner())) {
                source.method_9213(class_2561.method_43471("nsvc.error.no_permission_private"));
                return 0;
            }
        }

        player.method_17355(new class_3908() {
            @Override
            public class_2561 method_5476() {
                return class_2561.method_43469("nsvc.chest.title", name);
            }

            @Override
            public class_1703 createMenu(int syncId, class_1661 inv, class_1657 player) {
                int rows = chest.getChestSize() == VirtualChest.Size.SMALL ? 3 : 6;
                class_3917<?> type = rows == 3 ? class_3917.field_17326 : class_3917.field_17327;
                return new class_1707(type, syncId, inv, chest, rows);
            }
        });

        source.method_9226(() -> class_2561.method_43469("nsvc.open.opening", name).method_27692(class_124.field_1080), false);
        return 1;
    }

    private static int deleteChest(CommandContext<class_2168> ctx, boolean cancel) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        String target = StringArgumentType.getString(ctx, "target");
        String name = StringArgumentType.getString(ctx, "name");
        boolean isPublic = target.equalsIgnoreCase("allplayer");
        class_3222 player = source.method_44023();

        VirtualChestData data = VirtualChestData.getInstance();
        VirtualChest chest = data.getChest(name);
        if (chest == null) {
            source.method_9213(class_2561.method_43469("nsvc.error.not_exist", name));
            return 0;
        }

        if (chest.isPublic() != isPublic) {
            source.method_9213(class_2561.method_43471("nsvc.error.type_mismatch"));
            return 0;
        }

        boolean isAdmin = hasAdminPermission(source);

        if (cancel) {
            if (!chest.isPendingDeletion()) {
                source.method_9213(class_2561.method_43471("nsvc.error.not_pending"));
                return 0;
            }
            if (!isAdmin) {
                if (!isPublic && (player == null || !player.method_5667().equals(chest.getOwner()))) {
                    source.method_9213(class_2561.method_43471("nsvc.error.no_permission_cancel"));
                    return 0;
                }
            }
            chest.setPendingDeletion(false, 0);
            source.method_9226(() -> class_2561.method_43469("nsvc.delete.cancelled", name).method_27692(class_124.field_1060), true);
            return 1;
        }

        if (isAdmin) {
            chest.setPendingDeletion(false, 0);
            data.deleteChest(name);
            source.method_9226(() -> class_2561.method_43469("nsvc.delete.admin_success", name).method_27692(class_124.field_1060), true);
            return 1;
        } else {
            if (isPublic) {
                long currentTime = source.method_9225().method_75260();
                if (!chest.isPendingDeletion()) {
                    chest.setPendingDeletion(true, currentTime);
                    source.method_9226(() -> class_2561.method_43469("nsvc.delete.public_pending", name)
                            .method_10852(class_2561.method_43470(" '/NSvc allplayer delete " + name + " close'")).method_27692(class_124.field_1054), false);
                    return 1;
                } else {
                    if (currentTime - chest.getDeletionStartTime() >= THREE_DAYS_TICKS) {
                        data.deleteChest(name);
                        source.method_9226(() -> class_2561.method_43469("nsvc.delete.public_done", name).method_27692(class_124.field_1060), true);
                        return 1;
                    } else {
                        long remaining = THREE_DAYS_TICKS - (currentTime - chest.getDeletionStartTime());
                        long remainingDays = remaining / 24000;
                        source.method_9213(class_2561.method_43469("nsvc.delete.remaining_days", remainingDays));
                        return 0;
                    }
                }
            } else {
                if (player == null || !player.method_5667().equals(chest.getOwner())) {
                    source.method_9213(class_2561.method_43471("nsvc.error.no_permission_private"));
                    return 0;
                }
                if (!chest.isPendingDeletion()) {
                    chest.setPendingDeletion(true, source.method_9225().method_75260());
                    source.method_9226(() -> class_2561.method_43469("nsvc.delete.private_confirm", name).method_27692(class_124.field_1054), false);
                    return 1;
                } else {
                    long confirmTime = source.method_9225().method_75260() - chest.getDeletionStartTime();
                    if (confirmTime > 1200) {
                        chest.setPendingDeletion(false, 0);
                        source.method_9213(class_2561.method_43471("nsvc.delete.confirm_timeout"));
                        return 0;
                    }
                    chest.setPendingDeletion(false, 0);
                    data.deleteChest(name);
                    source.method_9226(() -> class_2561.method_43469("nsvc.delete.private_done", name).method_27692(class_124.field_1060), true);
                    return 1;
                }
            }
        }
    }

    private static int listChests(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        String target = StringArgumentType.getString(ctx, "target");
        boolean isPublic = target.equalsIgnoreCase("allplayer");
        class_3222 player = source.method_44023();
        UUID targetOwner = isPublic ? null : resolveTarget(source, target, false);

        VirtualChestData data = VirtualChestData.getInstance();
        int count = 0;
        source.method_9226(() -> class_2561.method_43469("nsvc.list.header", target).method_27692(class_124.field_1065), false);
        for (VirtualChest chest : data.getAllChests()) {
            if (chest.isPublic() != isPublic) continue;
            if (!isPublic) {
                if (!hasAdminPermission(source) && (player == null || !player.method_5667().equals(chest.getOwner()))) {
                    continue;
                }
                if (targetOwner != null && !targetOwner.equals(chest.getOwner())) {
                    continue;
                }
            }
            count++;
            String status = chest.isPendingDeletion() ? class_2561.method_43471("nsvc.list.pending").getString() : "";
            String sizeDisplay = chest.getChestSize() == VirtualChest.Size.SMALL ? "nsvc.size.small" : "nsvc.size.large";
            source.method_9226(() -> class_2561.method_43469("nsvc.list.entry", chest.getName(),
                    class_2561.method_43471(sizeDisplay).getString() + ", " + chest.method_5439(), status).method_27692(class_124.field_1080), false);
        }
        if (count == 0) {
            source.method_9226(() -> class_2561.method_43471("nsvc.list.empty").method_27692(class_124.field_1054), false);
        }
        return count;
    }
}